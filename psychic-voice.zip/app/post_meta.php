<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class post_meta extends Model
{
    //
}
